# OpenManus AI - Simple Setup Guide

## 🚀 One-Click Deploy to Render

This guide will help you deploy OpenManus AI to the web in just a few simple steps, even if you're not technical!

### What You'll Need (5 minutes setup)

1. **GitHub Account** (free) - to store your code
2. **Render Account** (free) - to host your website
3. **Supabase Account** (free) - for user accounts and data
4. **OpenRouter Account** (free trial) - for AI features

---

## Step 1: Get Your API Keys (5 minutes)

### A. Get Supabase Keys

1. Go to [supabase.com](https://supabase.com)
2. Click "Start your project" and sign up
3. Click "New project"
4. Fill in:
   - **Name**: `openmanus-ai`
   - **Password**: Create a strong password (save it!)
   - **Region**: Choose closest to you
5. Click "Create new project" (wait 2-3 minutes)
6. Go to **Settings** → **API**
7. Copy these two values (save them!):
   - **Project URL**: `https://xxxxxxxx.supabase.co`
   - **anon public key**: `eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...`

### B. Set Up Supabase Database

1. In your Supabase project, go to **SQL Editor**
2. Click "New query"
3. Copy and paste this code:

```sql
-- Create a table for public profiles
create table profiles (
  id uuid references auth.users on delete cascade,
  updated_at timestamp with time zone,
  username text unique,
  avatar_url text,
  website text,
  primary key (id),
  unique (username)
);

alter table profiles enable row level security;

create policy "Public profiles are viewable by everyone." on profiles
  for select using (true);

create policy "Users can insert their own profile." on profiles
  for insert with check (auth.uid() = id);

create policy "Users can update own profile." on profiles
  for update using (auth.uid() = id);

-- Create a table for chat messages
create table messages (
  id uuid primary key default gen_random_uuid(),
  session_id uuid not null,
  user_id uuid references auth.users on delete cascade,
  content jsonb not null,
  created_at timestamp with time zone default now()
);

alter table messages enable row level security;

create policy "Chat messages are viewable by authenticated users." on messages
  for select using (auth.role() = 'authenticated');

create policy "Users can insert their own chat messages." on messages
  for insert with check (auth.uid() = user_id);

create policy "Users can update their own chat messages." on messages
  for update using (auth.uid() = user_id);

-- Function to create new profile on new user signup
create function public.handle_new_user()
returns trigger as $$
begin
  insert into public.profiles (id, username)
  values (new.id, new.email);
  return new;
end;
$$
language plpgsql security definer;

-- Trigger to create new profile on new user signup
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();
```

4. Click **Run** (bottom right)
5. You should see "Success. No rows returned"

### C. Get OpenRouter API Key

1. Go to [openrouter.ai](https://openrouter.ai)
2. Click "Sign In" and create account
3. Go to "Keys" in the menu
4. Click "Create Key"
5. Name it "OpenManus AI"
6. Copy the key (starts with `sk-or-v1-...`)
7. **Important**: Add $5-10 credits in "Billing" section

---

## Step 2: Upload to GitHub (2 minutes)

1. Go to [github.com](https://github.com) and sign in
2. Click the **+** button (top right) → **New repository**
3. Name it: `openmanus-ai`
4. Make it **Public**
5. Click **Create repository**
6. Click **uploading an existing file**
7. Drag and drop the `openmanus-ai-app.zip` file
8. Click **Commit changes**

---

## Step 3: Deploy to Render (2 minutes)

### Option A: One-Click Deploy (Recommended)

1. Click this button: 

[![Deploy to Render](https://render.com/images/deploy-to-render-button.svg)](https://render.com/deploy?repo=https://github.com/YOUR-USERNAME/openmanus-ai)

**Replace `YOUR-USERNAME` with your actual GitHub username in the URL above**

2. Sign in to Render (or create free account)
3. It will automatically connect to your GitHub repo

### Option B: Manual Deploy

1. Go to [render.com](https://render.com) and sign up
2. Click **New +** → **Web Service**
3. Click **Connect** next to your `openmanus-ai` repository
4. Fill in:
   - **Name**: `openmanus-ai`
   - **Build Command**: `pnpm install && pnpm run build`
   - **Start Command**: `pnpm start`

---

## Step 4: Add Your API Keys (1 minute)

In Render, scroll down to **Environment Variables** and add:

| Key | Value |
|-----|-------|
| `VITE_SUPABASE_URL` | Your Supabase Project URL |
| `VITE_SUPABASE_ANON_KEY` | Your Supabase anon key |
| `VITE_OPENROUTER_API_KEY` | Your OpenRouter API key |

Click **Create Web Service**

---

## Step 5: Final Setup (1 minute)

1. Wait for deployment (2-3 minutes)
2. Copy your new website URL (looks like `https://openmanus-ai-xxxx.onrender.com`)
3. Go back to **Supabase** → **Authentication** → **Settings**
4. Set **Site URL** to your Render URL
5. Add your Render URL to **Redirect URLs**

---

## 🎉 You're Done!

Your OpenManus AI is now live! Visit your Render URL to:

- Create an account
- Chat with AI agents
- Upload files for analysis
- Access admin dashboard

### Need Help?

- **Blank page?** Check that all 3 environment variables are set correctly
- **Can't sign up?** Make sure Site URL is set in Supabase
- **AI not working?** Verify OpenRouter API key and account has credits

### Free Tier Limits

- **Render**: 750 hours/month (enough for personal use)
- **Supabase**: 50,000 monthly active users
- **OpenRouter**: Pay per use (very affordable)

---

**Total Setup Time: ~15 minutes**
**Monthly Cost: $0-5 (depending on usage)**

Enjoy your personal AI assistant! 🤖

