# Deploy OpenManus AI to Render

This guide provides step-by-step instructions for deploying the OpenManus AI web application to Render.

## Prerequisites

1. **GitHub Account**: Your code must be in a GitHub repository
2. **Render Account**: Sign up at [render.com](https://render.com)
3. **Supabase Account**: Sign up at [supabase.com](https://supabase.com)
4. **OpenRouter Account**: Sign up at [openrouter.ai](https://openrouter.ai)

## Step 1: Set Up Supabase Backend

### 1.1 Create Supabase Project

1. Go to [supabase.com](https://supabase.com) and sign in
2. Click "New Project"
3. Enter project name: "openmanus-ai"
4. Enter a secure database password
5. Select a region close to your users
6. Click "Create new project"

### 1.2 Configure Database Schema

1. Go to the SQL Editor in your Supabase dashboard
2. Create a new query and paste the following SQL:

```sql
-- Create a table for public profiles
create table profiles (
  id uuid references auth.users on delete cascade,
  updated_at timestamp with time zone,
  username text unique,
  avatar_url text,
  website text,
  primary key (id),
  unique (username)
);

alter table profiles enable row level security;

create policy "Public profiles are viewable by everyone." on profiles
  for select using (true);

create policy "Users can insert their own profile." on profiles
  for insert with check (auth.uid() = id);

create policy "Users can update own profile." on profiles
  for update using (auth.uid() = id);

-- Set up Realtime!
alter table profiles replica identity full;

-- Create a table for chat messages
create table messages (
  id uuid primary key default gen_random_uuid(),
  session_id uuid not null,
  user_id uuid references auth.users on delete cascade,
  content jsonb not null,
  created_at timestamp with time zone default now()
);

alter table messages enable row level security;

create policy "Chat messages are viewable by authenticated users." on messages
  for select using (auth.role() = 'authenticated');

create policy "Users can insert their own chat messages." on messages
  for insert with check (auth.uid() = user_id);

create policy "Users can update their own chat messages." on messages
  for update using (auth.uid() = user_id);

-- Set up Realtime for messages
alter table messages replica identity full;

-- Function to create new profile on new user signup
create function public.handle_new_user()
returns trigger as $$
begin
  insert into public.profiles (id, username)
  values (new.id, new.email);
  return new;
end;
$$
language plpgsql security definer;

-- Trigger to create new profile on new user signup
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();
```

3. Click "Run" to execute the SQL

### 1.3 Get API Keys

1. Go to Settings > API in your Supabase dashboard
2. Copy these values:
   - **Project URL**: `https://your-project-id.supabase.co`
   - **Anon public key**: `eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...`

## Step 2: Set Up OpenRouter API

1. Go to [openrouter.ai](https://openrouter.ai) and sign up
2. Go to "Keys" section and create a new API key
3. Copy the API key (starts with `sk-or-v1-...`)
4. Add credits to your account ($10-20 recommended for testing)

## Step 3: Push Code to GitHub

1. Create a new repository on GitHub
2. Push your OpenManus AI code to the repository:

```bash
git init
git add .
git commit -m "Initial commit: OpenManus AI application"
git branch -M main
git remote add origin https://github.com/yourusername/openmanus-ai.git
git push -u origin main
```

## Step 4: Deploy to Render

### 4.1 Create New Web Service

1. Go to [render.com](https://render.com) and sign in
2. Click "New +" and select "Web Service"
3. Connect your GitHub repository
4. Select your OpenManus AI repository

### 4.2 Configure Build Settings

**Basic Settings:**
- **Name**: `openmanus-ai`
- **Environment**: `Node`
- **Region**: Choose closest to your users
- **Branch**: `main`

**Build & Deploy Settings:**
- **Build Command**: `npm install && npm run build`
- **Start Command**: `npx serve -s dist -l 3000`

### 4.3 Add Environment Variables

In the Environment Variables section, add:

```
VITE_SUPABASE_URL=https://your-project-id.supabase.co
VITE_SUPABASE_ANON_KEY=your_supabase_anon_key
VITE_OPENROUTER_API_KEY=your_openrouter_api_key
```

### 4.4 Deploy

1. Click "Create Web Service"
2. Wait for the build and deployment to complete
3. Your app will be available at `https://your-app-name.onrender.com`

## Step 5: Configure Supabase for Production

1. Go to your Supabase dashboard
2. Navigate to Authentication > Settings
3. Update the following:
   - **Site URL**: `https://your-app-name.onrender.com`
   - **Redirect URLs**: Add `https://your-app-name.onrender.com/**`

## Step 6: Test Your Deployment

1. Visit your Render URL
2. Test user registration and login
3. Test chat functionality
4. Verify file uploads work
5. Check admin dashboard access

## Troubleshooting

### Common Issues

1. **Blank White Page**
   - Check browser console for errors
   - Verify all environment variables are set correctly
   - Ensure Supabase URL and keys are valid

2. **Build Failures**
   - Check build logs in Render dashboard
   - Verify package.json scripts are correct
   - Ensure all dependencies are listed

3. **Authentication Issues**
   - Verify Supabase redirect URLs are configured
   - Check that Site URL matches your Render domain
   - Test API keys in Supabase dashboard

### Performance Optimization

1. **Enable Render's CDN** in service settings
2. **Configure caching headers** for static assets
3. **Monitor performance** in Render dashboard

## Custom Domain (Optional)

1. In Render dashboard, go to Settings > Custom Domains
2. Add your custom domain
3. Configure DNS records as instructed
4. Update Supabase authentication settings with new domain

## Monitoring and Maintenance

1. **Monitor logs** in Render dashboard
2. **Set up alerts** for service health
3. **Monitor Supabase usage** and costs
4. **Track OpenRouter API usage** and costs

## Scaling

Render automatically scales your application based on traffic. For high-traffic applications:

1. Consider upgrading to a paid Render plan
2. Monitor resource usage
3. Optimize database queries
4. Implement caching strategies

Your OpenManus AI application should now be successfully deployed on Render!

