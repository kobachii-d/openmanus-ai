-- Create a table for public profiles
create table profiles (
  id uuid references auth.users on delete cascade,
  updated_at timestamp with time zone,
  username text unique,
  avatar_url text,
  website text,

  primary key (id),
  unique (username)
);

alter table profiles enable row level security;

create policy "Public profiles are viewable by everyone." on profiles
  for select using (true);

create policy "Users can insert their own profile." on profiles
  for insert with check (auth.uid() = id);

create policy "Users can update own profile." on profiles
  for update using (auth.uid() = id);

-- Set up Realtime!
alter table profiles replica identity full;

-- Create a table for chat messages
create table messages (
  id uuid primary key default gen_random_uuid(),
  session_id uuid not null,
  user_id uuid references auth.users on delete cascade,
  content jsonb not null,
  created_at timestamp with time zone default now()
);

alter table messages enable row level security;

create policy "Chat messages are viewable by authenticated users." on messages
  for select using (auth.role() = 'authenticated');

create policy "Users can insert their own chat messages." on messages
  for insert with check (auth.uid() = user_id);

create policy "Users can update their own chat messages." on messages
  for update using (auth.uid() = user_id);

-- Set up Realtime for messages
alter table messages replica identity full;

-- Function to create new profile on new user signup
create function public.handle_new_user()
returns trigger as $$
begin
  insert into public.profiles (id, username)
  values (new.id, new.email);
  return new;
end;
$$
language plpgsql security definer;

-- Trigger to create new profile on new user signup
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();


