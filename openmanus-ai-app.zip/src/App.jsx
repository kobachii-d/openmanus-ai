import { useState, useEffect } from 'react'
import { supabase, isSupabaseConfigured } from './lib/supabaseClient'
import Auth from './components/Auth'
import Chat from './components/Chat'
import AdminDashboard from './components/AdminDashboard'
import LoadingSpinner from './components/LoadingSpinner'
import ErrorBoundary from './components/ErrorBoundary'
import { ThemeProvider, useTheme } from './components/ThemeProvider'
import { Sun, Moon, MessageSquare, BarChart3, LogOut, User, Settings } from 'lucide-react'
import './App.css'

function ConfigurationError() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 dark:bg-gray-900">
      <div className="text-center p-8 max-w-2xl">
        <div className="text-blue-500 text-6xl mb-6">⚙️</div>
        <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
          Welcome to OpenManus AI
        </h1>
        <p className="text-gray-600 dark:text-gray-400 mb-6">
          This application requires configuration to connect to Supabase and OpenRouter services.
        </p>
        
        <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-lg text-left">
          <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
            Required Environment Variables:
          </h2>
          <div className="space-y-2 text-sm font-mono bg-gray-100 dark:bg-gray-700 p-4 rounded">
            <div>VITE_SUPABASE_URL=your_supabase_url</div>
            <div>VITE_SUPABASE_ANON_KEY=your_supabase_anon_key</div>
            <div>VITE_OPENROUTER_API_KEY=your_openrouter_api_key</div>
          </div>
          
          <div className="mt-6">
            <h3 className="font-semibold text-gray-900 dark:text-white mb-2">
              Setup Instructions:
            </h3>
            <ol className="text-sm text-gray-600 dark:text-gray-400 space-y-1">
              <li>1. Create a Supabase project at supabase.com</li>
              <li>2. Get an OpenRouter API key at openrouter.ai</li>
              <li>3. Set the environment variables in your deployment platform</li>
              <li>4. Redeploy the application</li>
            </ol>
          </div>
        </div>
        
        <p className="text-sm text-gray-500 dark:text-gray-400 mt-6">
          See the included RENDER_DEPLOYMENT.md guide for detailed setup instructions.
        </p>
      </div>
    </div>
  )
}

function AppContent() {
  const [session, setSession] = useState(null)
  const [currentView, setCurrentView] = useState('chat')
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const { theme, toggleTheme } = useTheme()

  useEffect(() => {
    let mounted = true

    const initializeAuth = async () => {
      try {
        if (!isSupabaseConfigured) {
          if (mounted) {
            setLoading(false)
          }
          return
        }

        // Get initial session
        const { data: { session }, error } = await supabase.auth.getSession()
        
        if (error) {
          console.error('Auth error:', error)
          setError('Authentication service error. Please check your Supabase configuration.')
        } else if (mounted) {
          setSession(session)
        }
      } catch (err) {
        console.error('Failed to initialize auth:', err)
        if (mounted) {
          setError('Failed to connect to authentication service.')
        }
      } finally {
        if (mounted) {
          setLoading(false)
        }
      }
    }

    initializeAuth()

    // Listen for auth changes only if Supabase is configured
    let subscription
    if (isSupabaseConfigured) {
      const { data } = supabase.auth.onAuthStateChange((_event, session) => {
        if (mounted) {
          setSession(session)
          setError(null)
        }
      })
      subscription = data
    }

    return () => {
      mounted = false
      if (subscription) {
        subscription.unsubscribe()
      }
    }
  }, [])

  const handleSignOut = async () => {
    if (!isSupabaseConfigured) return

    try {
      const { error } = await supabase.auth.signOut()
      if (error) {
        console.error('Error signing out:', error.message)
        setError('Failed to sign out. Please try again.')
      }
    } catch (err) {
      console.error('Sign out error:', err)
      setError('Failed to sign out. Please try again.')
    }
  }

  if (!isSupabaseConfigured) {
    return <ConfigurationError />
  }

  if (loading) {
    return <LoadingSpinner />
  }

  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50 dark:bg-gray-900">
        <div className="text-center p-8 max-w-md">
          <div className="text-red-500 text-4xl mb-4">⚠️</div>
          <h1 className="text-xl font-bold text-gray-900 dark:text-white mb-4">
            Service Error
          </h1>
          <p className="text-gray-600 dark:text-gray-400 mb-6">
            {error}
          </p>
          <button
            onClick={() => window.location.reload()}
            className="px-6 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600"
          >
            Retry
          </button>
        </div>
      </div>
    )
  }

  if (!session) {
    return <Auth />
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      {/* Navigation */}
      <nav className="bg-white dark:bg-gray-800 shadow-sm border-b border-gray-200 dark:border-gray-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <div className="flex items-center">
                  <div className="h-8 w-8 bg-blue-600 rounded-lg flex items-center justify-center">
                    <span className="text-white font-bold text-sm">OM</span>
                  </div>
                  <span className="ml-2 text-xl font-semibold text-gray-900 dark:text-white">
                    OpenManus AI
                  </span>
                </div>
              </div>
              <div className="hidden sm:ml-6 sm:flex sm:space-x-8">
                <button
                  onClick={() => setCurrentView('chat')}
                  className={`inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium ${
                    currentView === 'chat'
                      ? 'border-blue-500 text-blue-600 dark:text-blue-400'
                      : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300 dark:text-gray-400 dark:hover:text-gray-300'
                  }`}
                >
                  <MessageSquare className="h-4 w-4 mr-2" />
                  Chat
                </button>
                <button
                  onClick={() => setCurrentView('admin')}
                  className={`inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium ${
                    currentView === 'admin'
                      ? 'border-blue-500 text-blue-600 dark:text-blue-400'
                      : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300 dark:text-gray-400 dark:hover:text-gray-300'
                  }`}
                >
                  <BarChart3 className="h-4 w-4 mr-2" />
                  Admin
                </button>
              </div>
            </div>

            <div className="flex items-center space-x-4">
              {/* Theme Toggle */}
              <button
                onClick={toggleTheme}
                className="p-2 rounded-md text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-700"
                title={`Switch to ${theme === 'light' ? 'dark' : 'light'} mode`}
              >
                {theme === 'light' ? <Moon className="h-5 w-5" /> : <Sun className="h-5 w-5" />}
              </button>

              {/* User Menu */}
              <div className="flex items-center space-x-2">
                <div className="flex items-center space-x-2 text-sm text-gray-700 dark:text-gray-300">
                  <User className="h-4 w-4" />
                  <span>{session.user.email}</span>
                </div>
                <button
                  onClick={handleSignOut}
                  className="p-2 rounded-md text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-700"
                  title="Sign out"
                >
                  <LogOut className="h-5 w-5" />
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Mobile Navigation */}
        <div className="sm:hidden">
          <div className="pt-2 pb-3 space-y-1">
            <button
              onClick={() => setCurrentView('chat')}
              className={`block pl-3 pr-4 py-2 border-l-4 text-base font-medium w-full text-left ${
                currentView === 'chat'
                  ? 'bg-blue-50 border-blue-500 text-blue-700 dark:bg-blue-900/20 dark:text-blue-300'
                  : 'border-transparent text-gray-600 hover:text-gray-800 hover:bg-gray-50 hover:border-gray-300 dark:text-gray-400 dark:hover:text-gray-200 dark:hover:bg-gray-700'
              }`}
            >
              <MessageSquare className="h-4 w-4 inline mr-2" />
              Chat
            </button>
            <button
              onClick={() => setCurrentView('admin')}
              className={`block pl-3 pr-4 py-2 border-l-4 text-base font-medium w-full text-left ${
                currentView === 'admin'
                  ? 'bg-blue-50 border-blue-500 text-blue-700 dark:bg-blue-900/20 dark:text-blue-300'
                  : 'border-transparent text-gray-600 hover:text-gray-800 hover:bg-gray-50 hover:border-gray-300 dark:text-gray-400 dark:hover:text-gray-200 dark:hover:bg-gray-700'
              }`}
            >
              <BarChart3 className="h-4 w-4 inline mr-2" />
              Admin
            </button>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="flex-1">
        {currentView === 'chat' && <Chat user={session.user} />}
        {currentView === 'admin' && <AdminDashboard user={session.user} />}
      </main>
    </div>
  )
}

export default function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider>
        <AppContent />
      </ThemeProvider>
    </ErrorBoundary>
  )
}

