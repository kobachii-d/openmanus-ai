import { useState, useEffect } from 'react'
import { Brain, Search, FileText, Code, CheckCircle } from 'lucide-react'

export default function ThinkingProcess({ isVisible, steps = [] }) {
  const [currentStep, setCurrentStep] = useState(0)

  useEffect(() => {
    if (steps.length > 0 && currentStep < steps.length - 1) {
      const timer = setTimeout(() => {
        setCurrentStep(prev => prev + 1)
      }, 1000)
      return () => clearTimeout(timer)
    }
  }, [currentStep, steps.length])

  if (!isVisible || steps.length === 0) return null

  const getStepIcon = (type) => {
    switch (type) {
      case 'thinking': return <Brain className="h-4 w-4" />
      case 'searching': return <Search className="h-4 w-4" />
      case 'reading': return <FileText className="h-4 w-4" />
      case 'processing': return <Code className="h-4 w-4" />
      case 'complete': return <CheckCircle className="h-4 w-4" />
      default: return <Brain className="h-4 w-4" />
    }
  }

  return (
    <div className="bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg p-4 mb-4">
      <div className="flex items-center space-x-2 mb-3">
        <Brain className="h-5 w-5 text-blue-500" />
        <h3 className="text-sm font-medium text-gray-900 dark:text-white">
          AI Agent Thinking Process
        </h3>
      </div>

      <div className="space-y-2">
        {steps.map((step, index) => (
          <div
            key={index}
            className={`flex items-center space-x-3 p-2 rounded transition-all duration-300 ${
              index <= currentStep
                ? 'bg-blue-50 dark:bg-blue-900/20 text-blue-700 dark:text-blue-300'
                : 'text-gray-400 dark:text-gray-600'
            }`}
          >
            <div className={`flex-shrink-0 ${
              index <= currentStep ? 'text-blue-500' : 'text-gray-400'
            }`}>
              {getStepIcon(step.type)}
            </div>
            
            <div className="flex-1">
              <div className="text-sm font-medium">{step.title}</div>
              {step.description && (
                <div className="text-xs opacity-75">{step.description}</div>
              )}
            </div>

            {index <= currentStep && (
              <div className="flex-shrink-0">
                {index === currentStep ? (
                  <div className="w-2 h-2 bg-blue-500 rounded-full animate-pulse"></div>
                ) : (
                  <CheckCircle className="h-4 w-4 text-green-500" />
                )}
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  )
}

