import { useState, useRef, useEffect } from 'react'
import { Send, Upload, Bot, Plus, Settings } from 'lucide-react'
import { supabase } from '../lib/supabaseClient'
import { OpenRouterClient } from '../lib/openrouter'
import ChatMessage from './ChatMessage'
import ThinkingProcess from './ThinkingProcess'

export default function Chat({ user }) {
  const [messages, setMessages] = useState([])
  const [input, setInput] = useState('')
  const [isLoading, setIsLoading] = useState(false)
  const [files, setFiles] = useState([])
  const [currentSessionId, setCurrentSessionId] = useState(null)
  const [showThinking, setShowThinking] = useState(false)
  const [thinkingSteps, setThinkingSteps] = useState([])
  const messagesEndRef = useRef(null)
  const fileInputRef = useRef(null)

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  useEffect(() => {
    // Create a new session when component mounts
    setCurrentSessionId(crypto.randomUUID())
    loadChatHistory()
  }, [])

  const loadChatHistory = async () => {
    try {
      const { data, error } = await supabase
        .from('messages')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: true })
        .limit(50)

      if (error) throw error

      const formattedMessages = data.map(msg => ({
        id: msg.id,
        role: msg.content.role,
        content: msg.content.content,
        files: msg.content.files,
        timestamp: new Date(msg.created_at)
      }))

      setMessages(formattedMessages)
    } catch (error) {
      console.error('Error loading chat history:', error)
    }
  }

  const saveMessage = async (message) => {
    try {
      const { error } = await supabase
        .from('messages')
        .insert({
          session_id: currentSessionId,
          user_id: user.id,
          content: {
            role: message.role,
            content: message.content,
            files: message.files
          }
        })

      if (error) throw error
    } catch (error) {
      console.error('Error saving message:', error)
    }
  }

  const handleFileUpload = (event) => {
    const selectedFiles = Array.from(event.target.files)
    setFiles(prev => [...prev, ...selectedFiles])
  }

  const removeFile = (index) => {
    setFiles(prev => prev.filter((_, i) => i !== index))
  }

  const simulateThinkingProcess = () => {
    const steps = [
      { type: 'thinking', title: 'Analyzing your request', description: 'Understanding the context and requirements' },
      { type: 'searching', title: 'Gathering information', description: 'Searching for relevant data and resources' },
      { type: 'processing', title: 'Processing files', description: 'Analyzing uploaded files and content' },
      { type: 'thinking', title: 'Formulating response', description: 'Generating comprehensive answer' },
      { type: 'complete', title: 'Response ready', description: 'Delivering results to you' }
    ]

    setThinkingSteps(steps)
    setShowThinking(true)

    // Hide thinking process after completion
    setTimeout(() => {
      setShowThinking(false)
      setThinkingSteps([])
    }, steps.length * 1000 + 2000)
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    if (!input.trim() && files.length === 0) return

    const userMessage = {
      id: Date.now(),
      role: 'user',
      content: input,
      files: files.map(f => ({ name: f.name, size: f.size, type: f.type })),
      timestamp: new Date()
    }

    setMessages(prev => [...prev, userMessage])
    await saveMessage(userMessage)

    setInput('')
    setFiles([])
    setIsLoading(true)

    // Show thinking process
    simulateThinkingProcess()

    // Initialize AI client
    const apiKey = import.meta.env.VITE_OPENROUTER_API_KEY
    if (!apiKey) {
      console.error('OpenRouter API key not configured')
      setIsLoading(false)
      return
    }

    const client = new OpenRouterClient(apiKey)
    
    // Process files if any
    let processedFiles = []
    if (files.length > 0) {
      try {
        processedFiles = await client.processFiles(files)
      } catch (error) {
        console.error('Error processing files:', error)
      }
    }

    // Prepare messages for AI
    const conversationHistory = messages.map(msg => ({
      role: msg.role,
      content: msg.content
    }))

    conversationHistory.push({
      role: 'user',
      content: input
    })

    const formattedMessages = client.formatMessagesWithFiles(conversationHistory, processedFiles)

    // Create AI message
    const aiMessage = {
      id: Date.now() + 1,
      role: 'assistant',
      content: '',
      timestamp: new Date()
    }

    setMessages(prev => [...prev, aiMessage])

    // Stream AI response
    await client.streamChat(
      formattedMessages,
      (chunk) => {
        setMessages(prev => prev.map(msg => 
          msg.id === aiMessage.id 
            ? { ...msg, content: msg.content + chunk }
            : msg
        ))
      },
      async () => {
        setIsLoading(false)
        // Save AI response
        const finalMessage = messages.find(msg => msg.id === aiMessage.id)
        if (finalMessage) {
          await saveMessage(finalMessage)
        }
      },
      (error) => {
        console.error('AI streaming error:', error)
        setMessages(prev => prev.map(msg => 
          msg.id === aiMessage.id 
            ? { ...msg, content: 'Sorry, I encountered an error while processing your request. Please try again.' }
            : msg
        ))
        setIsLoading(false)
      }
    )
  }

  const startNewChat = () => {
    setMessages([])
    setCurrentSessionId(crypto.randomUUID())
  }

  return (
    <div className="flex flex-col h-screen bg-gray-50 dark:bg-gray-900">
      {/* Header */}
      <div className="bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 p-4">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-xl font-semibold text-gray-900 dark:text-white">
              OpenManus AI Assistant
            </h1>
            <p className="text-sm text-gray-500 dark:text-gray-400">
              Powered by advanced AI agents with multimodal capabilities
            </p>
          </div>
          <div className="flex items-center space-x-2">
            <button
              onClick={startNewChat}
              className="p-2 text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-md"
              title="New Chat"
            >
              <Plus className="h-5 w-5" />
            </button>
            <button
              className="p-2 text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-md"
              title="Settings"
            >
              <Settings className="h-5 w-5" />
            </button>
          </div>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4">
        {messages.length === 0 && (
          <div className="text-center text-gray-500 dark:text-gray-400 mt-8">
            <Bot className="h-12 w-12 mx-auto mb-4 opacity-50" />
            <h2 className="text-lg font-medium mb-2">Welcome to OpenManus AI</h2>
            <p className="mb-4">Start a conversation with your AI assistant. You can:</p>
            <div className="text-sm space-y-1 max-w-md mx-auto">
              <p>• Upload and analyze images, documents, and code files</p>
              <p>• Ask questions and get detailed explanations</p>
              <p>• Request help with complex tasks and research</p>
              <p>• See the AI's thinking process in real-time</p>
            </div>
          </div>
        )}

        {/* Thinking Process Visualization */}
        <ThinkingProcess isVisible={showThinking} steps={thinkingSteps} />

        {/* Messages */}
        <div className="space-y-1">
          {messages.map((message) => (
            <ChatMessage 
              key={message.id} 
              message={message} 
              isStreaming={isLoading && message.role === 'assistant' && message.id === Math.max(...messages.map(m => m.id))}
            />
          ))}
        </div>
        <div ref={messagesEndRef} />
      </div>

      {/* Input */}
      <div className="bg-white dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700 p-4">
        {files.length > 0 && (
          <div className="mb-3 flex flex-wrap gap-2">
            {files.map((file, index) => (
              <div
                key={index}
                className="flex items-center space-x-2 bg-gray-100 dark:bg-gray-700 px-3 py-1 rounded-full text-sm"
              >
                <span>📎 {file.name}</span>
                <button
                  onClick={() => removeFile(index)}
                  className="text-red-500 hover:text-red-700 font-bold"
                >
                  ×
                </button>
              </div>
            ))}
          </div>
        )}

        <form onSubmit={handleSubmit} className="flex items-end space-x-2">
          <div className="flex-1">
            <textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Type your message... (Shift+Enter for new line)"
              className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white resize-none"
              rows="1"
              style={{ minHeight: '40px', maxHeight: '120px' }}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault()
                  handleSubmit(e)
                }
              }}
            />
          </div>
          
          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            className="p-2 text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg"
            title="Upload files"
          >
            <Upload className="h-5 w-5" />
          </button>
          
          <button
            type="submit"
            disabled={isLoading || (!input.trim() && files.length === 0)}
            className="p-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 disabled:opacity-50 disabled:cursor-not-allowed"
            title="Send message"
          >
            <Send className="h-5 w-5" />
          </button>
        </form>

        <input
          ref={fileInputRef}
          type="file"
          multiple
          accept=".txt,.md,.js,.py,.html,.css,.json,.csv,.png,.jpg,.jpeg,.gif,.webp,.pdf"
          onChange={handleFileUpload}
          className="hidden"
        />
      </div>
    </div>
  )
}

