# OpenManus AI - Deployment Guide

This guide provides step-by-step instructions for deploying the OpenManus AI web application to production.

## Prerequisites

Before deploying, ensure you have:

1. **Supabase Account**: Sign up at [supabase.com](https://supabase.com)
2. **OpenRouter Account**: Sign up at [openrouter.ai](https://openrouter.ai)
3. **Deployment Platform**: Choose from Vercel, Netlify, or your own server

## Step 1: Set Up Supabase Backend

### 1.1 Create Supabase Project

1. Go to [supabase.com](https://supabase.com) and sign in
2. Click "New Project"
3. Choose your organization
4. Enter project name: "openmanus-ai"
5. Enter a secure database password
6. Select a region close to your users
7. Click "Create new project"

### 1.2 Configure Database Schema

1. Go to the SQL Editor in your Supabase dashboard
2. Create a new query and paste the following SQL:

```sql
-- Create a table for public profiles
create table profiles (
  id uuid references auth.users on delete cascade,
  updated_at timestamp with time zone,
  username text unique,
  avatar_url text,
  website text,
  primary key (id),
  unique (username)
);

alter table profiles enable row level security;

create policy "Public profiles are viewable by everyone." on profiles
  for select using (true);

create policy "Users can insert their own profile." on profiles
  for insert with check (auth.uid() = id);

create policy "Users can update own profile." on profiles
  for update using (auth.uid() = id);

-- Set up Realtime!
alter table profiles replica identity full;

-- Create a table for chat messages
create table messages (
  id uuid primary key default gen_random_uuid(),
  session_id uuid not null,
  user_id uuid references auth.users on delete cascade,
  content jsonb not null,
  created_at timestamp with time zone default now()
);

alter table messages enable row level security;

create policy "Chat messages are viewable by authenticated users." on messages
  for select using (auth.role() = 'authenticated');

create policy "Users can insert their own chat messages." on messages
  for insert with check (auth.uid() = user_id);

create policy "Users can update their own chat messages." on messages
  for update using (auth.uid() = user_id);

-- Set up Realtime for messages
alter table messages replica identity full;

-- Function to create new profile on new user signup
create function public.handle_new_user()
returns trigger as $$
begin
  insert into public.profiles (id, username)
  values (new.id, new.email);
  return new;
end;
$$
language plpgsql security definer;

-- Trigger to create new profile on new user signup
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();
```

3. Click "Run" to execute the SQL

### 1.3 Configure Authentication

1. Go to Authentication > Settings in your Supabase dashboard
2. **Site URL**: Add your production domain (e.g., `https://your-app.vercel.app`)
3. **Redirect URLs**: Add your production domain with auth callback
4. **Email Templates**: Customize if needed
5. **Providers**: Enable Google OAuth if desired:
   - Go to Authentication > Providers
   - Enable Google
   - Add your Google OAuth credentials

### 1.4 Get API Keys

1. Go to Settings > API in your Supabase dashboard
2. Copy the following values:
   - **Project URL**: `https://your-project-id.supabase.co`
   - **Anon public key**: `eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...`

## Step 2: Set Up OpenRouter API

### 2.1 Create OpenRouter Account

1. Go to [openrouter.ai](https://openrouter.ai)
2. Sign up for an account
3. Verify your email address

### 2.2 Get API Key

1. Go to your OpenRouter dashboard
2. Navigate to "Keys" section
3. Click "Create Key"
4. Give it a name (e.g., "OpenManus AI Production")
5. Copy the API key (starts with `sk-or-v1-...`)

### 2.3 Add Credits

1. Go to "Billing" in your OpenRouter dashboard
2. Add credits to your account for API usage
3. Recommended: Start with $10-20 for testing

## Step 3: Deploy to Vercel (Recommended)

### 3.1 Prepare Repository

1. Push your code to GitHub, GitLab, or Bitbucket
2. Ensure your repository is public or accessible to Vercel

### 3.2 Deploy to Vercel

1. Go to [vercel.com](https://vercel.com) and sign in
2. Click "New Project"
3. Import your repository
4. Configure project settings:
   - **Framework Preset**: Vite
   - **Build Command**: `pnpm run build`
   - **Output Directory**: `dist`
   - **Install Command**: `pnpm install`

### 3.3 Add Environment Variables

In Vercel dashboard, go to Settings > Environment Variables and add:

```
VITE_SUPABASE_URL=https://your-project-id.supabase.co
VITE_SUPABASE_ANON_KEY=your_supabase_anon_key
VITE_OPENROUTER_API_KEY=your_openrouter_api_key
```

### 3.4 Deploy

1. Click "Deploy"
2. Wait for deployment to complete
3. Your app will be available at `https://your-app.vercel.app`

## Step 4: Deploy to Netlify (Alternative)

### 4.1 Prepare Repository

1. Push your code to GitHub, GitLab, or Bitbucket

### 4.2 Deploy to Netlify

1. Go to [netlify.com](https://netlify.com) and sign in
2. Click "New site from Git"
3. Choose your Git provider and repository
4. Configure build settings:
   - **Build command**: `pnpm run build`
   - **Publish directory**: `dist`

### 4.3 Add Environment Variables

In Netlify dashboard, go to Site settings > Environment variables and add:

```
VITE_SUPABASE_URL=https://your-project-id.supabase.co
VITE_SUPABASE_ANON_KEY=your_supabase_anon_key
VITE_OPENROUTER_API_KEY=your_openrouter_api_key
```

### 4.4 Configure Redirects

Create a `_redirects` file in the `public` directory:

```
/*    /index.html   200
```

This ensures proper routing for the single-page application.

## Step 5: Custom Server Deployment

### 5.1 Build the Application

```bash
pnpm run build
```

### 5.2 Upload Files

1. Upload the contents of the `dist` directory to your web server
2. Ensure your server serves `index.html` for all routes

### 5.3 Server Configuration

**Nginx Example:**
```nginx
server {
    listen 80;
    server_name your-domain.com;
    root /path/to/your/dist;
    index index.html;

    location / {
        try_files $uri $uri/ /index.html;
    }
}
```

**Apache Example:**
```apache
<VirtualHost *:80>
    ServerName your-domain.com
    DocumentRoot /path/to/your/dist
    
    <Directory /path/to/your/dist>
        RewriteEngine On
        RewriteBase /
        RewriteRule ^index\.html$ - [L]
        RewriteCond %{REQUEST_FILENAME} !-f
        RewriteCond %{REQUEST_FILENAME} !-d
        RewriteRule . /index.html [L]
    </Directory>
</VirtualHost>
```

## Step 6: Post-Deployment Configuration

### 6.1 Update Supabase Settings

1. Go to your Supabase dashboard
2. Update Authentication > Settings:
   - **Site URL**: Your production domain
   - **Redirect URLs**: Add your production domain

### 6.2 Test the Application

1. Visit your deployed application
2. Test user registration and login
3. Test chat functionality
4. Test file uploads
5. Verify admin dashboard access

### 6.3 Monitor Performance

1. Set up monitoring in your deployment platform
2. Monitor Supabase usage in the dashboard
3. Monitor OpenRouter API usage

## Step 7: Domain Configuration (Optional)

### 7.1 Custom Domain on Vercel

1. Go to your project settings in Vercel
2. Click "Domains"
3. Add your custom domain
4. Configure DNS records as instructed

### 7.2 Custom Domain on Netlify

1. Go to Site settings > Domain management
2. Add custom domain
3. Configure DNS records as instructed

## Security Considerations

### 7.1 Environment Variables

- Never commit API keys to your repository
- Use environment variables for all sensitive data
- Rotate API keys regularly

### 7.2 Supabase Security

- Enable Row Level Security (RLS) on all tables
- Review and test security policies
- Monitor authentication logs

### 7.3 HTTPS

- Ensure your application is served over HTTPS
- Most deployment platforms provide HTTPS by default

## Monitoring and Maintenance

### 7.4 Application Monitoring

- Set up error tracking (e.g., Sentry)
- Monitor performance metrics
- Set up uptime monitoring

### 7.5 Database Monitoring

- Monitor Supabase usage and performance
- Set up alerts for high usage
- Regular database backups

### 7.6 API Usage Monitoring

- Monitor OpenRouter API usage
- Set up billing alerts
- Optimize API calls for cost efficiency

## Troubleshooting

### Common Deployment Issues

1. **Build Failures**
   - Check Node.js version compatibility
   - Verify all dependencies are installed
   - Check for TypeScript errors

2. **Environment Variable Issues**
   - Ensure all required variables are set
   - Check variable names (case-sensitive)
   - Restart deployment after adding variables

3. **Authentication Issues**
   - Verify Supabase URL and keys
   - Check redirect URLs configuration
   - Test authentication flow

4. **API Connection Issues**
   - Verify OpenRouter API key
   - Check API usage limits
   - Test API connectivity

### Getting Help

- Check deployment platform documentation
- Review Supabase documentation
- Check OpenRouter API documentation
- Create issues in the project repository

## Scaling Considerations

### Performance Optimization

- Enable CDN for static assets
- Optimize images and media files
- Implement caching strategies
- Monitor and optimize database queries

### Cost Management

- Monitor API usage and costs
- Implement usage limits if needed
- Optimize for efficient API calls
- Consider usage-based scaling

This deployment guide should help you successfully deploy the OpenManus AI application to production. Follow each step carefully and test thoroughly before making the application available to users.

