# OpenManus AI Web Application

A comprehensive web application that democratizes access to advanced artificial intelligence agent capabilities through a user-friendly interface.

## Features

### 🤖 AI Agent Interaction
- **Text-based Chat**: Engage with AI agents through natural language
- **Multimodal Support**: Upload and process images, documents, and code files
- **Streaming Responses**: Real-time AI responses with typewriter effect
- **Thinking Process Visualization**: See how the AI agent plans and executes tasks

### 🔐 Authentication & User Management
- **Email/Password Authentication**: Traditional sign-up and sign-in
- **Google OAuth**: One-click social login
- **Magic Link**: Passwordless authentication via email
- **Persistent Sessions**: Secure session management with Supabase Auth

### 💬 Chat History & Real-time Features
- **Persistent Chat History**: All conversations saved and searchable
- **Real-time Synchronization**: Live message updates across devices
- **Session Management**: Organize conversations by sessions
- **File Upload Support**: Attach various file types to conversations

### 🎨 Modern UI/UX
- **Minimal Professional Design**: Clean, focused interface
- **Dark/Light Mode**: Automatic system preference detection with manual toggle
- **Responsive Design**: Optimized for desktop and mobile devices
- **Accessibility**: WCAG compliant with proper contrast and navigation

### 📊 Admin Dashboard
- **Usage Analytics**: Track user activity and system metrics
- **Real-time Monitoring**: Live system status and performance
- **User Management**: View user statistics and activity
- **System Health**: Monitor database, AI service, and authentication status

## Technology Stack

- **Frontend**: React 19 with Vite
- **Styling**: Tailwind CSS with shadcn/ui components
- **Backend**: Supabase (PostgreSQL, Auth, Real-time)
- **AI Integration**: OpenRouter API with multimodal LLM support
- **Icons**: Lucide React
- **State Management**: React hooks and context

## Prerequisites

- Node.js 18+ and pnpm
- Supabase account and project
- OpenRouter API key

## Installation

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd openmanus-ai-app
   ```

2. **Install dependencies**
   ```bash
   pnpm install
   ```

3. **Set up environment variables**
   Create a `.env.local` file in the root directory:
   ```env
   # Supabase Configuration
   VITE_SUPABASE_URL=your_supabase_project_url
   VITE_SUPABASE_ANON_KEY=your_supabase_anon_key
   
   # OpenRouter Configuration
   VITE_OPENROUTER_API_KEY=your_openrouter_api_key
   ```

4. **Set up Supabase Database**
   
   Create a new Supabase project and run the following SQL in the SQL editor:

   ```sql
   -- Create a table for public profiles
   create table profiles (
     id uuid references auth.users on delete cascade,
     updated_at timestamp with time zone,
     username text unique,
     avatar_url text,
     website text,
     primary key (id),
     unique (username)
   );

   alter table profiles enable row level security;

   create policy "Public profiles are viewable by everyone." on profiles
     for select using (true);

   create policy "Users can insert their own profile." on profiles
     for insert with check (auth.uid() = id);

   create policy "Users can update own profile." on profiles
     for update using (auth.uid() = id);

   -- Create a table for chat messages
   create table messages (
     id uuid primary key default gen_random_uuid(),
     session_id uuid not null,
     user_id uuid references auth.users on delete cascade,
     content jsonb not null,
     created_at timestamp with time zone default now()
   );

   alter table messages enable row level security;

   create policy "Chat messages are viewable by authenticated users." on messages
     for select using (auth.role() = 'authenticated');

   create policy "Users can insert their own chat messages." on messages
     for insert with check (auth.uid() = user_id);

   create policy "Users can update their own chat messages." on messages
     for update using (auth.uid() = user_id);

   -- Function to create new profile on new user signup
   create function public.handle_new_user()
   returns trigger as $$
   begin
     insert into public.profiles (id, username)
     values (new.id, new.email);
     return new;
   end;
   $$
   language plpgsql security definer;

   -- Trigger to create new profile on new user signup
   create trigger on_auth_user_created
     after insert on auth.users
     for each row execute procedure public.handle_new_user();
   ```

5. **Configure Supabase Authentication**
   
   In your Supabase dashboard:
   - Go to Authentication > Settings
   - Add your site URL to "Site URL"
   - Configure Google OAuth if desired
   - Enable email confirmations if needed

## Development

Start the development server:

```bash
pnpm run dev
```

The application will be available at `http://localhost:5173`

## Building for Production

```bash
pnpm run build
```

The built files will be in the `dist` directory.

## Deployment

### Using Vercel (Recommended)

1. Connect your repository to Vercel
2. Add environment variables in Vercel dashboard
3. Deploy automatically on push

### Using Netlify

1. Connect your repository to Netlify
2. Set build command: `pnpm run build`
3. Set publish directory: `dist`
4. Add environment variables

### Manual Deployment

1. Build the project: `pnpm run build`
2. Upload the `dist` folder to your web server
3. Configure your server to serve the `index.html` for all routes

## Configuration

### Supabase Setup

1. Create a new project at [supabase.com](https://supabase.com)
2. Get your project URL and anon key from Settings > API
3. Run the database setup SQL provided above
4. Configure authentication providers as needed

### OpenRouter Setup

1. Sign up at [openrouter.ai](https://openrouter.ai)
2. Get your API key from the dashboard
3. Add credits to your account for API usage

### File Upload Configuration

The application supports the following file types:
- **Text files**: .txt, .md, .json, .csv
- **Code files**: .js, .py, .html, .css
- **Images**: .png, .jpg, .jpeg, .gif, .webp
- **Documents**: .pdf (with proper configuration)

## Features in Detail

### AI Agent Capabilities

The AI agent can:
- Process and analyze uploaded files
- Perform web searches (when configured)
- Generate detailed responses with context
- Maintain conversation history
- Show thinking process visualization

### Security Features

- Row Level Security (RLS) for data protection
- Secure file upload with type validation
- Authentication state management
- CORS protection
- Input sanitization

### Performance Optimizations

- Code splitting and lazy loading
- Optimized bundle size
- Efficient state management
- Real-time updates with minimal overhead
- Responsive image handling

## Troubleshooting

### Common Issues

1. **Environment variables not loading**
   - Ensure `.env.local` file is in the root directory
   - Restart the development server after changes

2. **Supabase connection errors**
   - Verify your project URL and API keys
   - Check if your database is running
   - Ensure RLS policies are correctly configured

3. **OpenRouter API errors**
   - Verify your API key is correct
   - Check your account credits
   - Ensure the model is available

4. **File upload issues**
   - Check file size limits
   - Verify supported file types
   - Ensure proper MIME type handling

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Support

For support and questions:
- Create an issue in the repository
- Check the documentation
- Review the troubleshooting section

## Roadmap

- [ ] Advanced file processing capabilities
- [ ] Integration with more AI models
- [ ] Enhanced admin analytics
- [ ] Mobile app development
- [ ] API for third-party integrations
- [ ] Advanced search and filtering
- [ ] Team collaboration features

